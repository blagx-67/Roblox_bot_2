const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

const SCRIPTS_DIR = path.join(__dirname, "../../scripts");

// GET /api/scripts — list available scripts
router.get("/", (req, res) => {
  try {
    const files = fs.readdirSync(SCRIPTS_DIR).filter((f) => f.endsWith(".lua"));
    res.json({ scripts: files });
  } catch {
    res.json({ scripts: [] });
  }
});

// GET /api/scripts/:name — get script content
router.get("/:name", (req, res) => {
  const file = path.join(SCRIPTS_DIR, req.params.name);
  if (!file.startsWith(SCRIPTS_DIR)) return res.status(400).json({ error: "Invalid path" });
  if (!fs.existsSync(file)) return res.status(404).json({ error: "Script not found" });
  res.json({ name: req.params.name, content: fs.readFileSync(file, "utf8") });
});

module.exports = router;
