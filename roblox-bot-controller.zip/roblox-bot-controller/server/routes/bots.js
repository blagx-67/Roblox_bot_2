const express = require("express");
const router = express.Router();
const { getBots, getBot } = require("../ws");

// GET /api/bots — list all connected bots
router.get("/", (req, res) => {
  res.json({ bots: getBots() });
});

// GET /api/bots/:id — get a single bot
router.get("/:id", (req, res) => {
  const bot = getBot(req.params.id);
  if (!bot) return res.status(404).json({ error: "Bot not found" });
  res.json({ id: req.params.id, info: bot.info, connectedAt: bot.connectedAt });
});

// POST /api/bots/:id/execute — execute raw Lua on a bot
router.post("/:id/execute", (req, res) => {
  const bot = getBot(req.params.id);
  if (!bot) return res.status(404).json({ error: "Bot not found" });

  const { script } = req.body;
  if (!script) return res.status(400).json({ error: "Missing 'script' field" });

  // Optional: wait for result (up to 5s)
  const timeout = setTimeout(() => {
    bot.ws._resultCallback = null;
    res.json({ status: "sent", note: "No result returned within timeout" });
  }, 5000);

  bot.ws._resultCallback = (data) => {
    clearTimeout(timeout);
    res.json({ status: "ok", result: data });
  };

  bot.ws.send(JSON.stringify({ event: "server:execute", data: { script } }));
});

// POST /api/bots/:id/command — send a named command
router.post("/:id/command", (req, res) => {
  const bot = getBot(req.params.id);
  if (!bot) return res.status(404).json({ error: "Bot not found" });

  const { command, args } = req.body;
  if (!command) return res.status(400).json({ error: "Missing 'command' field" });

  bot.ws.send(JSON.stringify({ event: "server:command", data: { command, args: args || {} } }));
  res.json({ status: "sent", command, args });
});

// POST /api/bots/broadcast — send to ALL bots
router.post("/broadcast/execute", (req, res) => {
  const bots = getBots();
  const { script } = req.body;
  if (!script) return res.status(400).json({ error: "Missing 'script' field" });

  let sent = 0;
  for (const b of bots) {
    const bot = getBot(b.id);
    if (bot && bot.ws.readyState === 1) {
      bot.ws.send(JSON.stringify({ event: "server:execute", data: { script } }));
      sent++;
    }
  }

  res.json({ status: "broadcast", sent });
});

// DELETE /api/bots/:id — disconnect a bot
router.delete("/:id", (req, res) => {
  const bot = getBot(req.params.id);
  if (!bot) return res.status(404).json({ error: "Bot not found" });

  bot.ws.send(JSON.stringify({ event: "server:disconnect" }));
  bot.ws.close();
  res.json({ status: "disconnected", id: req.params.id });
});

module.exports = router;
